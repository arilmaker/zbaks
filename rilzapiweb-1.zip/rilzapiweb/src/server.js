const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { readDatabase, writeDatabase } = require("./database");
const { hashPassword, verifyPassword, createSession, readSession, createApiKey, SESSION_MAX_AGE_MS } = require("./auth");
const { getHomeTracks, searchTracks, getPlaylist } = require("./youtube");
const { enrichTracks } = require("./metadata");

function wantsEnrich(value) { return !["0", "false", "off", "no"].includes(String(value || "").toLowerCase()); }

function readEnvFile() {
  const envPath = path.join(__dirname, "..", ".env");
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^["']|["']$/g, "");
  }
}
readEnvFile();

const port = Number(process.env.PORT || 3000);
const sessionSecret = process.env.SESSION_SECRET || "ganti-session-secret-sebelum-produksi";
const adminEmail = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
const telegramBotUrl = String(process.env.TELEGRAM_BOT_URL || "").trim();
const adminBotToken = String(process.env.ADMIN_BOT_TOKEN || "");
const emailPattern = /^[^\s@]+@gmail\.com$/i;
const publicRoot = path.join(__dirname, "..", "public");

function json(res, statusCode, data, headers = {}) {
  res.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*", ...headers });
  res.end(JSON.stringify(data));
}
function publicUser(user) { return { id: user.id, email: user.email, role: user.role, createdAt: user.createdAt }; }
function parseCookies(req) {
  return Object.fromEntries(String(req.headers.cookie || "").split(";").map((item) => item.trim().split(/=(.*)/s)).filter((item) => item[0]).map((item) => [item[0], decodeURIComponent(item[1] || "")]));
}
function getCurrentUser(req) {
  const session = readSession(parseCookies(req).session, sessionSecret);
  return session ? readDatabase().users.find((user) => user.id === session.userId) || null : null;
}
function setSession(res, userId) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return "session=" + createSession(userId, sessionSecret) + "; HttpOnly; SameSite=Lax; Path=/; Max-Age=" + Math.floor(SESSION_MAX_AGE_MS / 1000) + secure;
}
function activePremium(key) { return key.plan === "premium" && (!key.expiresAt || new Date(key.expiresAt).getTime() > Date.now()); }
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => { data += chunk; if (data.length > 32768) req.destroy(); });
    req.on("end", () => { try { resolve(data ? JSON.parse(data) : {}); } catch (_) { reject(new Error("JSON body tidak valid.")); } });
    req.on("error", reject);
  });
}
function requireApiKey(req, url, res) {
  const apiKey = req.headers["x-api-key"] || url.searchParams.get("apikey");
  if (!apiKey) { json(res, 401, { status: false, message: "API key diperlukan. Kirim lewat header x-api-key atau parameter apikey." }); return null; }
  const database = readDatabase();
  const key = database.apiKeys.find((item) => item.key === apiKey && item.active);
  if (!key) { json(res, 401, { status: false, message: "API key tidak valid." }); return null; }
  const user = database.users.find((item) => item.id === key.userId);
  if (!user) { json(res, 401, { status: false, message: "Pemilik API key tidak ditemukan." }); return null; }
  const unlimited = user.role === "admin" || activePremium(key);
  const today = new Date().toISOString().slice(0, 10);
  if (!key.usage || key.usage.date !== today) key.usage = { date: today, count: 0 };
  if (!unlimited && key.usage.count >= 50) {
    json(res, 429, { status: false, message: "Limit harian 50 request sudah habis. Coba lagi besok atau upgrade premium.", limit: 50, used: key.usage.count });
    return null;
  }
  key.usage.count += 1;
  key.lastUsedAt = new Date().toISOString();
  writeDatabase(database);
  return { key, user, limit: unlimited ? null : 50 };
}
function apiResponse(res, access, result, extra = {}) {
  json(res, 200, { status: true, result, meta: { limit: access.user.role === "admin" || activePremium(access.key) ? "unlimited" : access.limit, used: access.key.usage.count, plan: access.key.plan, ...extra } });
}
function serveStatic(res, pathname) {
  const file = pathname === "/" ? "index.html" : pathname.slice(1);
  const target = path.resolve(publicRoot, file);
  if (!target.startsWith(publicRoot) || !fs.existsSync(target) || fs.statSync(target).isDirectory()) { json(res, 404, { status: false, message: "Tidak ditemukan." }); return; }
  const types = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"application/javascript; charset=utf-8" };
  res.writeHead(200, { "Content-Type": types[path.extname(target)] || "application/octet-stream" });
  fs.createReadStream(target).pipe(res);
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") { res.writeHead(204, { "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type, x-api-key, x-admin-token", "Access-Control-Allow-Methods":"GET, POST, OPTIONS" }); return res.end(); }
  const url = new URL(req.url, "http://" + req.headers.host);
  const pathname = url.pathname;

  try {
    if (req.method === "POST" && pathname === "/auth/register") {
      const body = await readBody(req);
      const email = String(body.email || "").trim().toLowerCase();
      const password = String(body.password || "");
      if (!emailPattern.test(email)) return json(res, 400, { status: false, message: "Gunakan alamat Gmail yang valid." });
      if (password.length < 8) return json(res, 400, { status: false, message: "Password minimal 8 karakter." });
      const database = readDatabase();
      if (database.users.some((user) => user.email === email)) return json(res, 409, { status: false, message: "Email ini sudah terdaftar." });
      const now = new Date().toISOString();
      const user = { id: crypto.randomUUID(), email, passwordHash: hashPassword(password), role: adminEmail && email === adminEmail ? "admin" : "user", createdAt: now };
      const key = { id: crypto.randomUUID(), userId: user.id, key: createApiKey(), name: "API key utama", plan: "free", active: true, expiresAt: null, usage: { date: now.slice(0, 10), count: 0 }, createdAt: now, lastUsedAt: null };
      database.users.push(user); database.apiKeys.push(key); writeDatabase(database);
      return json(res, 201, { status: true, user: publicUser(user), apiKey: key.key }, { "Set-Cookie": setSession(res, user.id) });
    }

    if (req.method === "POST" && pathname === "/auth/login") {
      const body = await readBody(req);
      const user = readDatabase().users.find((item) => item.email === String(body.email || "").trim().toLowerCase());
      if (!user || !verifyPassword(String(body.password || ""), user.passwordHash)) return json(res, 401, { status: false, message: "Email atau password salah." });
      return json(res, 200, { status: true, user: publicUser(user) }, { "Set-Cookie": setSession(res, user.id) });
    }

    if (req.method === "POST" && pathname === "/auth/logout") return json(res, 200, { status: true }, { "Set-Cookie": "session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0" });

    if (req.method === "GET" && pathname === "/api/account") {
      const user = getCurrentUser(req);
      if (!user) return json(res, 401, { status: false, message: "Silakan login terlebih dahulu." });
      const keys = readDatabase().apiKeys.filter((key) => key.userId === user.id).map((key) => ({ id:key.id, key:key.key, name:key.name, plan:activePremium(key) ? "premium" : key.plan, active:key.active, expiresAt:key.expiresAt, usage:key.usage, lastUsedAt:key.lastUsedAt }));
      return json(res, 200, { status: true, user: publicUser(user), apiKeys: keys, pricing: { weekly: 10000, permanent: 50000 }, telegramBotUrl });
    }

    if (req.method === "POST" && pathname === "/api/keys") {
      const user = getCurrentUser(req);
      if (!user) return json(res, 401, { status:false, message:"Silakan login terlebih dahulu." });
      const body = await readBody(req); const database = readDatabase(); const now = new Date().toISOString();
      const key = { id:crypto.randomUUID(), userId:user.id, key:createApiKey(), name:String(body.name || "API key baru").slice(0,60), plan:"free", active:true, expiresAt:null, usage:{ date:now.slice(0,10), count:0 }, createdAt:now, lastUsedAt:null };
      database.apiKeys.push(key); writeDatabase(database); return json(res, 201, { status:true, apiKey:key });
    }

    if (req.method === "POST" && pathname === "/api/admin/premium") {
      const admin = getCurrentUser(req);
      if ((!admin || admin.role !== "admin") && (!adminBotToken || req.headers["x-admin-token"] !== adminBotToken)) return json(res, 403, { status:false, message:"Khusus admin." });
      const body = await readBody(req); const email = String(body.email || "").trim().toLowerCase(); const plan = String(body.plan || "");
      if (!emailPattern.test(email)) return json(res, 400, { status:false, message:"Email Gmail tidak valid." });
      if (!["weekly","permanent"].includes(plan)) return json(res, 400, { status:false, message:"Plan harus weekly atau permanent." });
      const database = readDatabase(); const user = database.users.find((item) => item.email === email);
      if (!user) return json(res, 404, { status:false, message:"Pengguna belum terdaftar." });
      const now = new Date(); const key = { id:crypto.randomUUID(), userId:user.id, key:createApiKey(), name:"Premium " + (plan === "weekly" ? "mingguan" : "permanen"), plan:"premium", active:true, expiresAt: plan === "weekly" ? new Date(now.getTime() + 604800000).toISOString() : null, usage:{date:now.toISOString().slice(0,10),count:0},createdAt:now.toISOString(),lastUsedAt:null };
      database.apiKeys.push(key); writeDatabase(database); return json(res, 201, { status:true, apiKey:key.key, plan, expiresAt:key.expiresAt, user:publicUser(user) });
    }

    if (req.method === "GET" && pathname === "/api/stats") {
      const database = readDatabase();
      return json(res, 200, { status:true, users:database.users.length, apiKeys:database.apiKeys.length, premiumKeys:database.apiKeys.filter(activePremium).length, endpoints:3 });
    }

    if (req.method === "GET" && pathname === "/api/v1") return json(res, 200, { name:"Musik API", version:"v1", authentication:"Gunakan ?apikey=API_KEY atau header x-api-key.", endpoints:["GET /api/v1/music/home","GET /api/v1/music/search?q=nama+lagu","GET /api/v1/music/playlist?url=https://www.youtube.com/playlist?list=..."] });

    if (req.method === "GET" && ["/api/v1/music/home", "/api/v1/music/search", "/api/v1/music/playlist"].includes(pathname)) {
      const access = requireApiKey(req, url, res); if (!access) return;
      const enrich = wantsEnrich(url.searchParams.get("enrich"));
      if (pathname === "/api/v1/music/home") { let tracks = await getHomeTracks(); if (enrich) tracks = await enrichTracks(tracks); return apiResponse(res, access, tracks, { count: tracks.length, enriched: enrich }); }
      if (pathname === "/api/v1/music/search") {
        const query = String(url.searchParams.get("q") || "").trim();
        if (!query) return json(res, 400, { status:false, message:"Parameter q diperlukan." });
        let tracks = await searchTracks(query); if (enrich) tracks = await enrichTracks(tracks);
        return apiResponse(res, access, tracks, { query, count:tracks.length, enriched: enrich });
      }
      const playlistUrl = String(url.searchParams.get("url") || "").trim();
      if (!playlistUrl) return json(res, 400, { status:false, message:"Parameter url playlist diperlukan." });
      const playlist = await getPlaylist(playlistUrl); if (enrich) playlist.tracks = await enrichTracks(playlist.tracks);
      return apiResponse(res, access, playlist, { count:playlist.tracks.length, enriched: enrich });
    }

    if (req.method === "GET") return serveStatic(res, pathname);
    return json(res, 404, { status:false, message:"Tidak ditemukan." });
  } catch (error) {
    const isYoutube = pathname.startsWith("/api/v1/music/");
    return json(res, isYoutube ? 502 : 500, { status:false, message:isYoutube ? "YouTube sedang tidak dapat diambil." : "Terjadi kesalahan pada server.", detail:error.message });
  }
});

server.listen(port, () => console.log("Musik API berjalan di http://localhost:" + port));
