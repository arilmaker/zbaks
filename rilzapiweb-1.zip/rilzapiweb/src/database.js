const fs = require("fs");
const path = require("path");

const databasePath = path.join(__dirname, "..", "database.json");
const emptyDatabase = { users: [], apiKeys: [] };

function readDatabase() {
  if (!fs.existsSync(databasePath)) return structuredClone(emptyDatabase);
  try {
    const database = JSON.parse(fs.readFileSync(databasePath, "utf8"));
    return { users: Array.isArray(database.users) ? database.users : [], apiKeys: Array.isArray(database.apiKeys) ? database.apiKeys : [] };
  } catch (_) {
    throw new Error("database.json tidak dapat dibaca. Periksa format JSON-nya.");
  }
}

function writeDatabase(database) {
  const temporaryPath = databasePath + ".tmp";
  fs.writeFileSync(temporaryPath, JSON.stringify(database, null, 2) + "\n", "utf8");
  fs.renameSync(temporaryPath, databasePath);
}

module.exports = { readDatabase, writeDatabase };
