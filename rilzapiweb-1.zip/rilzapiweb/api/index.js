const crypto = require("crypto");
const { createClient } = require("@supabase/supabase-js");
const { hashPassword, verifyPassword, createSession, readSession, createApiKey, SESSION_MAX_AGE_MS } = require("../src/auth");
const { getHomeTracks, searchTracks, getPlaylist } = require("../src/youtube");
const { enrichTracks } = require("../src/metadata");

function wantsEnrich(value) { return !["0", "false", "off", "no"].includes(String(value || "").toLowerCase()); }

const emailPattern = /^[^\s@]+@gmail\.com$/i;
const sessionSecret = process.env.SESSION_SECRET || "ganti-session-secret-sebelum-produksi";
const adminEmail = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
const telegramBotUrl = String(process.env.TELEGRAM_BOT_URL || "").trim();
const adminBotToken = String(process.env.ADMIN_BOT_TOKEN || "");

function database() {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error("SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY wajib diatur di Vercel.");
  }
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
}
function json(res, status, body, headers = {}) {
  res.status(status).set({ "Access-Control-Allow-Origin": "*", ...headers }).json(body);
}
function userView(row) { return { id: row.id, email: row.email, role: row.role, createdAt: row.created_at }; }
function keyView(row) {
  return { id: row.id, key: row.key, name: row.name, plan: isPremium(row) ? "premium" : row.plan, active: row.active, expiresAt: row.expires_at, usage: { date: row.usage_date, count: row.usage_count }, lastUsedAt: row.last_used_at };
}
function isPremium(key) { return key.plan === "premium" && (!key.expires_at || new Date(key.expires_at).getTime() > Date.now()); }
function cookies(req) {
  return Object.fromEntries(String(req.headers.cookie || "").split(";").map((part) => part.trim().split(/=(.*)/s)).filter((part) => part[0]).map((part) => [part[0], decodeURIComponent(part[1] || "")]));
}
async function body(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") return JSON.parse(req.body || "{}");
  return {};
}
async function currentUser(req, db) {
  const session = readSession(cookies(req).session, sessionSecret);
  if (!session) return null;
  const { data } = await db.from("users").select("*").eq("id", session.userId).maybeSingle();
  return data || null;
}
function sessionCookie(userId) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return "session=" + createSession(userId, sessionSecret) + "; HttpOnly; SameSite=Lax; Path=/; Max-Age=" + Math.floor(SESSION_MAX_AGE_MS / 1000) + secure;
}
async function accessApi(req, db) {
  const value = req.headers["x-api-key"] || req.query.apikey;
  if (!value) return { error: "API_KEY_REQUIRED" };
  const { data, error } = await db.rpc("consume_api_key", { p_api_key: value });
  if (error) return { error: error.message.includes("LIMIT_EXCEEDED") ? "LIMIT_EXCEEDED" : "INVALID_API_KEY" };
  const row = data && data[0];
  return row ? { key: { id:row.api_key_id, key:row.key_value, plan:row.plan_value, usage_count:row.usage_count_value, expires_at:row.expires_at_value }, role:row.user_role_value } : { error: "INVALID_API_KEY" };
}
function apiResult(res, access, result, extra = {}) {
  const unlimited = access.role === "admin" || (access.key.plan === "premium" && (!access.key.expires_at || new Date(access.key.expires_at).getTime() > Date.now()));
  json(res, 200, { status:true, result, meta:{ limit: unlimited ? "unlimited" : 50, used:access.key.usage_count, plan:access.key.plan, ...extra } });
}

module.exports = async (req, res) => {
  if (req.method === "OPTIONS") return res.status(204).set({ "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type, x-api-key, x-admin-token", "Access-Control-Allow-Methods":"GET, POST, OPTIONS" }).end();
  const path = req.url.split("?")[0];
  try {
    const db = database();

    if (req.method === "POST" && path === "/auth/register") {
      const input = await body(req); const email = String(input.email || "").trim().toLowerCase(); const password = String(input.password || "");
      if (!emailPattern.test(email)) return json(res, 400, { status:false, message:"Gunakan alamat Gmail yang valid." });
      if (password.length < 8) return json(res, 400, { status:false, message:"Password minimal 8 karakter." });
      const now = new Date().toISOString();
      const user = { id:crypto.randomUUID(), email, password_hash:hashPassword(password), role:adminEmail && email === adminEmail ? "admin" : "user", created_at:now };
      const { error:userError } = await db.from("users").insert(user);
      if (userError) return json(res, userError.code === "23505" ? 409 : 500, { status:false, message:userError.code === "23505" ? "Email ini sudah terdaftar." : "Akun tidak dapat dibuat." });
      const key = { id:crypto.randomUUID(), user_id:user.id, key:createApiKey(), name:"API key utama", plan:"free", active:true, usage_date:now.slice(0,10), usage_count:0, created_at:now };
      const { error:keyError } = await db.from("api_keys").insert(key);
      if (keyError) return json(res, 500, { status:false, message:"API key tidak dapat dibuat." });
      return json(res, 201, { status:true, user:userView(user), apiKey:key.key }, { "Set-Cookie":sessionCookie(user.id) });
    }

    if (req.method === "POST" && path === "/auth/login") {
      const input = await body(req); const email = String(input.email || "").trim().toLowerCase();
      const { data:user } = await db.from("users").select("*").eq("email", email).maybeSingle();
      if (!user || !verifyPassword(String(input.password || ""), user.password_hash)) return json(res, 401, { status:false, message:"Email atau password salah." });
      return json(res, 200, { status:true, user:userView(user) }, { "Set-Cookie":sessionCookie(user.id) });
    }

    if (req.method === "POST" && path === "/auth/logout") return json(res, 200, { status:true }, { "Set-Cookie":"session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0" });

    if (req.method === "GET" && path === "/api/account") {
      const user = await currentUser(req, db);
      if (!user) return json(res, 401, { status:false, message:"Silakan login terlebih dahulu." });
      const { data:keys, error } = await db.from("api_keys").select("*").eq("user_id", user.id).order("created_at", { ascending:true });
      if (error) throw error;
      return json(res, 200, { status:true, user:userView(user), apiKeys:(keys || []).map(keyView), pricing:{ weekly:10000, permanent:50000 }, telegramBotUrl });
    }

    if (req.method === "POST" && path === "/api/keys") {
      const user = await currentUser(req, db);
      if (!user) return json(res, 401, { status:false, message:"Silakan login terlebih dahulu." });
      const input = await body(req); const now = new Date().toISOString();
      const key = { id:crypto.randomUUID(), user_id:user.id, key:createApiKey(), name:String(input.name || "API key baru").slice(0,60), plan:"free", active:true, usage_date:now.slice(0,10), usage_count:0, created_at:now };
      const { error } = await db.from("api_keys").insert(key);
      if (error) throw error;
      return json(res, 201, { status:true, apiKey:keyView(key) });
    }

    if (req.method === "POST" && path === "/api/admin/premium") {
      const user = await currentUser(req, db);
      if ((!user || user.role !== "admin") && (!adminBotToken || req.headers["x-admin-token"] !== adminBotToken)) return json(res, 403, { status:false, message:"Khusus admin." });
      const input = await body(req); const email = String(input.email || "").trim().toLowerCase(); const plan = String(input.plan || "");
      if (!emailPattern.test(email) || !["weekly","permanent"].includes(plan)) return json(res, 400, { status:false, message:"Email atau plan tidak valid." });
      const { data:buyer } = await db.from("users").select("*").eq("email", email).maybeSingle();
      if (!buyer) return json(res, 404, { status:false, message:"Pengguna belum terdaftar." });
      const now = new Date(); const key = { id:crypto.randomUUID(), user_id:buyer.id, key:createApiKey(), name:"Premium " + (plan === "weekly" ? "mingguan" : "permanen"), plan:"premium", active:true, expires_at:plan === "weekly" ? new Date(now.getTime() + 604800000).toISOString() : null, usage_date:now.toISOString().slice(0,10), usage_count:0, created_at:now.toISOString() };
      const { error } = await db.from("api_keys").insert(key);
      if (error) throw error;
      return json(res, 201, { status:true, apiKey:key.key, plan, expiresAt:key.expires_at, user:userView(buyer) });
    }

    if (req.method === "GET" && path === "/api/stats") {
      const [users, keys, premium] = await Promise.all([
        db.from("users").select("id", { count:"exact", head:true }),
        db.from("api_keys").select("id", { count:"exact", head:true }),
        db.from("api_keys").select("id", { count:"exact", head:true }).eq("plan", "premium"),
      ]);
      return json(res, 200, { status:true, users:users.count || 0, apiKeys:keys.count || 0, premiumKeys:premium.count || 0, endpoints:3 });
    }

    if (req.method === "GET" && path === "/api/v1") return json(res, 200, { name:"Musik API", version:"v1", authentication:"Gunakan ?apikey=API_KEY atau header x-api-key.", note:"Tambahkan &enrich=0 untuk mematikan pencocokan metadata katalog.", endpoints:["GET /api/v1/music/home","GET /api/v1/music/search?q=nama+lagu","GET /api/v1/music/playlist?url=https://www.youtube.com/playlist?list=..."] });

    if (req.method === "GET" && ["/api/v1/music/home","/api/v1/music/search","/api/v1/music/playlist"].includes(path)) {
      const access = await accessApi(req, db);
      if (access.error === "API_KEY_REQUIRED") return json(res, 401, { status:false, message:"API key diperlukan." });
      if (access.error === "INVALID_API_KEY") return json(res, 401, { status:false, message:"API key tidak valid." });
      if (access.error === "LIMIT_EXCEEDED") return json(res, 429, { status:false, message:"Limit harian 50 request sudah habis.", limit:50, used:50 });
      const enrich = wantsEnrich(req.query.enrich);
      if (path === "/api/v1/music/home") { let tracks = await getHomeTracks(); if (enrich) tracks = await enrichTracks(tracks); return apiResult(res, access, tracks, { count:tracks.length, enriched:enrich }); }
      if (path === "/api/v1/music/search") {
        const query = String(req.query.q || "").trim();
        if (!query) return json(res, 400, { status:false, message:"Parameter q diperlukan." });
        let tracks = await searchTracks(query); if (enrich) tracks = await enrichTracks(tracks);
        return apiResult(res, access, tracks, { query, count:tracks.length, enriched:enrich });
      }
      const playlistUrl = String(req.query.url || "").trim();
      if (!playlistUrl) return json(res, 400, { status:false, message:"Parameter url playlist diperlukan." });
      const playlist = await getPlaylist(playlistUrl); if (enrich) playlist.tracks = await enrichTracks(playlist.tracks);
      return apiResult(res, access, playlist, { count:playlist.tracks.length, enriched:enrich });
    }
    return json(res, 404, { status:false, message:"Endpoint tidak ditemukan." });
  } catch (error) {
    return json(res, 500, { status:false, message:"Terjadi kesalahan pada server.", detail:process.env.NODE_ENV === "production" ? undefined : error.message });
  }
};
