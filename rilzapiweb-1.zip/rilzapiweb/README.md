# rilzapiweb

REST API musik YouTube dengan metadata artis asli (Spotify / Deezer / iTunes), dashboard, API key, limit harian, paket premium, dan siap deploy ke Vercel.

## Fitur

- Beranda YouTube, pencarian lagu, dan playlist publik.
- **Artis asli**: judul YouTube dibersihkan lalu dicocokkan dengan katalog musik, jadi `artist`, `title`, `album`, `cover`, `duration`, dan `preview` (30 detik) terisi seperti spotimate / spotidown.
- Registrasi Gmail, password di-hash `scrypt`, session cookie bertanda tangan.
- Akun gratis 50 request per hari. Admin dan premium tanpa batas.
- Key premium dibuat lewat bot Telegram atau akun admin.
- Web: beranda, dokumentasi dengan tombol Jalankan per endpoint, harga, dan dashboard.

## Cara metadata artis bekerja

1. Judul dibersihkan: `keshi - UNDERSTAND (Official Video) [4K]` menjadi artis `keshi`, judul `UNDERSTAND`.
2. Lagu dicari di katalog berurutan: **Spotify** (hanya jika key diisi), **Deezer**, **iTunes**. Deezer dan iTunes gratis tanpa key.
3. Kandidat diberi skor kemiripan judul dan artis. Hanya skor di atas 0,55 yang dipakai.
4. Jika tidak ada yang cocok, `source` bernilai `youtube` dan datanya tetap versi YouTube yang sudah dibersihkan.

Hasil dicache 6 jam di memori. Tambahkan `&enrich=0` untuk mematikan pencocokan dan hanya menerima data YouTube (lebih cepat).

Contoh respons:

```json
{
  "status": true,
  "result": [{
    "id": "2sD0m8xXq3o",
    "title": "Hati-Hati di Jalan",
    "artist": "Tulus",
    "artists": ["Tulus"],
    "album": "Manusia",
    "cover": "https://...",
    "thumbnail": "https://...",
    "duration": 246,
    "preview": "https://...mp3",
    "url": "https://www.youtube.com/watch?v=2sD0m8xXq3o",
    "playlist": "Pencarian: tulus",
    "source": "deezer",
    "sourceUrl": "https://www.deezer.com/...",
    "confidence": 1,
    "youtube": { "title": "Tulus - Hati-Hati di Jalan (Official Video)", "channel": "TULUS", "thumbnail": "https://..." }
  }],
  "meta": { "limit": 50, "used": 1, "plan": "free", "query": "tulus", "count": 1, "enriched": true }
}
```

## Endpoint

Semua endpoint GET. API key lewat `?apikey=` atau header `x-api-key`.

| Endpoint | Fungsi |
| --- | --- |
| `GET /api/v1` | Info API (tanpa key) |
| `GET /api/v1/music/home` | Beranda YouTube |
| `GET /api/v1/music/search?q=judul` | Cari lagu |
| `GET /api/v1/music/playlist?url=URL_PLAYLIST` | Isi playlist |
| `GET /api/stats` | Statistik publik (jumlah user dan key) |

Parameter tambahan: `enrich=0` untuk mematikan pencocokan katalog.

Kode status: `200` berhasil, `400` parameter kosong, `401` key salah atau tidak ada, `429` kuota habis, `5xx` YouTube gagal diambil.

## Jalankan di localhost

1. Salin `.env.example` menjadi `.env` lalu isi.
2. `node src/server.js`
3. Buka `http://localhost:3000`

Lokal memakai `database.json`. Butuh Node.js 18 atau lebih baru.

## Deploy ke Vercel (dengan Supabase)

Vercel tidak punya disk permanen, jadi data disimpan di Supabase (gratis).

### 1. Siapkan database

1. Buka supabase.com, buat project baru.
2. Menu **SQL Editor**, tempel seluruh isi `supabase/schema.sql`, klik **Run**.
3. Menu **Project Settings → API**, salin **Project URL** dan **service_role key**.

### 2. Upload ke GitHub

1. Buat repositori baru di GitHub (private lebih aman).
2. Upload seluruh isi folder ini. File `.env` dan `database.json` sengaja tidak ikut (sudah di `.gitignore`).

### 3. Impor ke Vercel

1. Buka vercel.com, **Add New → Project**, pilih repositori tadi.
2. Framework Preset biarkan **Other**. Build Command dan Output Directory dikosongkan.
3. Buka **Environment Variables**, isi (Production dan Preview):

| Variabel | Isi |
| --- | --- |
| `SUPABASE_URL` | Project URL dari Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | service_role key dari Supabase |
| `SESSION_SECRET` | Teks acak panjang (wajib, jangan pakai bawaan) |
| `ADMIN_EMAIL` | Gmail admin |
| `ADMIN_BOT_TOKEN` | Token rahasia untuk bot Telegram |
| `TELEGRAM_BOT_URL` | Link bot Telegram |
| `SPOTIFY_CLIENT_ID` | Opsional, dari developer.spotify.com/dashboard |
| `SPOTIFY_CLIENT_SECRET` | Opsional, pasangan dari di atas |

4. Klik **Deploy**. Hasilnya `https://nama-project.vercel.app`.

Setiap kali kamu push ke GitHub, Vercel otomatis deploy ulang. Setelah mengubah environment variable, lakukan **Redeploy**.

### Alternatif: lewat CLI

```
npm i -g vercel
vercel login
vercel --prod
```

Isi environment variable di dashboard Vercel (Settings → Environment Variables) lalu `vercel --prod` lagi.

### Catatan penting

- `SUPABASE_SERVICE_ROLE_KEY` hanya untuk server. Jangan masukkan ke JavaScript browser atau dibagikan.
- Setelah deploy, daftar akun dengan `ADMIN_EMAIL` supaya jadi admin.
- YouTube kadang memblokir IP server cloud. Jika `/music/*` sering error 5xx di Vercel tetapi lancar di lokal, itu penyebabnya. Opsi: gunakan hosting lain dengan IP berbeda, atau ganti sumber data ke YouTube Data API resmi.
- Fungsi Vercel dibatasi 30 detik (`vercel.json`). Playlist besar dengan pencocokan katalog bisa lambat, gunakan `enrich=0` bila perlu.
- Scraping YouTube melanggar ketentuan layanan YouTube. Pakai dengan risiko sendiri.

## Membuat key premium lewat bot

```
POST /api/admin/premium
x-admin-token: ADMIN_BOT_TOKEN
Content-Type: application/json

{ "email": "pembeli@gmail.com", "plan": "weekly" }
```

`weekly` berlaku 7 hari (Rp10.000), `permanent` tanpa kedaluwarsa (Rp50.000). Respons berisi `apiKey` untuk dikirim bot ke pembeli.
