create table if not exists public.users (
  id uuid primary key,
  email text not null unique,
  password_hash text not null,
  role text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.api_keys (
  id uuid primary key,
  user_id uuid not null references public.users(id) on delete cascade,
  key text not null unique,
  name text not null,
  plan text not null default 'free' check (plan in ('free', 'premium')),
  active boolean not null default true,
  expires_at timestamptz,
  usage_date date not null default current_date,
  usage_count integer not null default 0 check (usage_count >= 0),
  created_at timestamptz not null default now(),
  last_used_at timestamptz
);

create index if not exists api_keys_user_id_idx on public.api_keys(user_id);
create index if not exists api_keys_key_idx on public.api_keys(key);

create or replace function public.consume_api_key(p_api_key text)
returns table (
  api_key_id uuid,
  key_value text,
  plan_value text,
  usage_count_value integer,
  user_role_value text,
  expires_at_value timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  found_key public.api_keys%rowtype;
  found_user public.users%rowtype;
  unlimited boolean;
begin
  select * into found_key from public.api_keys
  where key = p_api_key and active = true
  for update;

  if not found then
    raise exception 'INVALID_API_KEY';
  end if;

  select * into found_user from public.users where id = found_key.user_id;
  if not found then
    raise exception 'INVALID_API_KEY';
  end if;

  unlimited := found_user.role = 'admin'
    or (found_key.plan = 'premium' and (found_key.expires_at is null or found_key.expires_at > now()));

  if found_key.usage_date <> current_date then
    found_key.usage_date := current_date;
    found_key.usage_count := 0;
  end if;

  if not unlimited and found_key.usage_count >= 50 then
    raise exception 'LIMIT_EXCEEDED';
  end if;

  found_key.usage_count := found_key.usage_count + 1;
  found_key.last_used_at := now();

  update public.api_keys
  set usage_date = found_key.usage_date,
      usage_count = found_key.usage_count,
      last_used_at = found_key.last_used_at
  where id = found_key.id;

  return query select found_key.id, found_key.key, found_key.plan, found_key.usage_count, found_user.role, found_key.expires_at;
end;
$$;

revoke all on function public.consume_api_key(text) from public;
grant execute on function public.consume_api_key(text) to service_role;
